﻿using Application.Filters;
using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Features.Products.Queries.GetAllProducts
{
    public class GetAllProductsParameter : RequestParameter
    {

    }
}
